export class Employee {

    id!: number;
    firstname!: string;
    lastname!: string;
    email!: string;
}
