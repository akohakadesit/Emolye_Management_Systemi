package com.project.springboot.model;

public enum Role {
	USER,
	ADMIN

}
